//
//  NewsApiData.swift
//  News
//
//  Created by Solaiman Ibrahimi on 2/27/24.
//  Copyright © 2024 Solaiman Ibrahimi. All rights reserved.
//

import Foundation

// Global variable to contain the API search results
var foundNewsList = [NewsStruct]()

/*
 ================================================
 |   Fetch and Process JSON Data from the API   |
 |   for the Given Category and Search Query    |
 ================================================
 */
public func getNewsFromApi(category: String, query: String) {
    
    foundNewsList = [NewsStruct]()
    
    /*
     **************************************************
     *   Obtain API URL String   *
     **************************************************
     */
    
    var newsApiUrl = ""
    // If selected category is default value "All", omit the category parameter.
    if category == "All" {
        newsApiUrl = "https://newsapi.org/v2/top-headlines?country=us&language=en&sortBy=\(query)"
    } else {
        newsApiUrl = "https://newsapi.org/v2/top-headlines?country=us&language=en&category=\(category)&sortBy=\(query)"
    }
    
    /*
     ***************************************************
     *   Fetch JSON Data from the API Asynchronously   *
     ***************************************************
     */
    var jsonDataFromApi: Data
    
    let jsonDataFetchedFromApi = getJsonDataFromApi(apiHeaders: newsApiHeaders, apiUrl: newsApiUrl, timeout: 10.0)
    
    if let jsonData = jsonDataFetchedFromApi {
        jsonDataFromApi = jsonData
    } else {
        return
    }
    
    /*
     **************************************************
     *   Process the JSON Data Fetched from the API   *
     **************************************************
     */
    do {
        /*
         Foundation framework’s JSONSerialization class is used to convert JSON data
         into Swift data types such as Dictionary, Array, String, Int, Double or Bool.
         */
        let jsonResponse = try JSONSerialization.jsonObject(with: jsonDataFromApi,
                                                            options: JSONSerialization.ReadingOptions.mutableContainers)
        //----------------------------
        // Obtain Top Level JSON Array
        //----------------------------
        
        var searchResultsJsonArray = [Any]()
        
        if let jsonArray = jsonResponse as? [Any] {
            searchResultsJsonArray = jsonArray
        } else {
            return
        }
        
        // Iterate over the searchResultsJsonArray containing JSON objects representing countries
        for newsJsonObject in searchResultsJsonArray {
            
            // Make sure that the array item is indeed a JSON object (Swift dictionary type)
            var newsDataDictionary = [String: Any]()
            
            if let jObject = newsJsonObject as? [String: Any] {
                newsDataDictionary = jObject
            } else {
                continue
            }
            
            var sourceName = ""
            if !(newsDataDictionary["source"] is NSNull) {
               if let source = newsDataDictionary["source"] as? String {
                   sourceName = source
               }
            }
            
            var authorName = ""
            if !(newsDataDictionary["author"] is NSNull) {
               if let author = newsDataDictionary["author"] as? String {
                   authorName = author
               }
            }
            
            var titleName = ""
            if !(newsDataDictionary["title"] is NSNull) {
               if let title = newsDataDictionary["title"] as? String {
                   titleName = title
               }
            }
            
            var descriptionName = ""
            if !(newsDataDictionary["description"] is NSNull) {
               if let description = newsDataDictionary["description"] as? String {
                   descriptionName = description
               }
            }
            
            var urlName = ""
            if !(newsDataDictionary["url"] is NSNull) {
               if let url = newsDataDictionary["url"] as? String {
                   urlName = url
               }
            }
        
            var urlToImageName = ""
            if !(newsDataDictionary["urlToImage"] is NSNull) {
               if let urlToImage = newsDataDictionary["urlToImage"] as? String {
                   urlToImageName = urlToImage
               }
            }

            var publishedAtName = ""
            if !(newsDataDictionary["publishedAt"] is NSNull) {
               if let publishedAt = newsDataDictionary["publishedAt"] as? String {
                   publishedAtName = publishedAt
               }
            }
            
            var contentName = ""
            if !(newsDataDictionary["content"] is NSNull) {
               if let content = newsDataDictionary["content"] as? String {
                   contentName = content
               }
            }
            
            //-------------------------------------------------------------------------
            // Create an Instance of News Struct and Append it to foundCountriesList
            //-------------------------------------------------------------------------
            let newsFound = NewsStruct(sourceName: sourceName, author: authorName, title: titleName, description: descriptionName, url: urlName, urlToImage: urlToImageName, publishedAt: publishedAtName, content: contentName)
            
            foundNewsList.append(newsFound)
            
        }   // End of for loop
        
        // Sort the list in alphabetical order with respect to commonName
        foundNewsList = foundNewsList.sorted(by: { $0.title < $1.title})
        
    } catch {
        return 
    }
    
}
