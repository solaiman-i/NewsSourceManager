//
//  DatabaseClasses.swift
//  News
//
//  Created by Solaiman Ibrahimi on 2/27/24.
//

import SwiftUI
import SwiftData

@Model
final class News {
    
    var sourceName: String
    var author: String
    var title: String
    var desc: String
    var url: String
    var urlToImage: String
    var publishedAt: String
    var content: String
    
    init(sourceName: String, author: String, title: String, description: String, url: String, urlToImage: String, publishedAt: String, content: String) {
        self.sourceName = sourceName
        self.author = author
        self.title = title
        self.desc = description
        self.url = url
        self.urlToImage = urlToImage
        self.publishedAt = publishedAt
        self.content = content
    }
    
}
