//
//  NewsStruct.swift
//  News
//
//  Created by Solaiman Ibrahimi on 2/27/24.
//

struct NewsStruct: Decodable, Hashable {
    var sourceName: String
    var author: String
    var title: String
    var description: String
    var url: String
    var urlToImage: String
    var publishedAt: String
    var content: String
}
