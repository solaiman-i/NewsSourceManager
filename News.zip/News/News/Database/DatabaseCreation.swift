//
//  DatabaseCreation.swift
//  News
//
//  Created by Solaiman Ibrahimi on 2/27/24.
//

import SwiftUI
import SwiftData

public func createNewsDatabase() {
    var modelContainer: ModelContainer
    
    do {
        // Create a database container to manage Country objects
        modelContainer = try ModelContainer(for: News.self)
    } catch {
        fatalError("Unable to create ModelContainer")
    }
    
    // Create the context (workspace) where Country objects will be managed
    let modelContext = ModelContext(modelContainer)

    let fetchDescriptor = FetchDescriptor<News>()
    
    var listOfAllNewsInDatabase = [News]()
    
    do {
        // Obtain all of the Country objects from the database
        listOfAllNewsInDatabase = try modelContext.fetch(fetchDescriptor)
    } catch {
        fatalError("Unable to fetch data from the database")
    }
    
    if !listOfAllNewsInDatabase.isEmpty {
        print("Database has already been created!")
        return
    }
    
    print("Database will be created!")
    
    /*
     ----------------------------------------------------------
     | *** The app is being launched for the first time ***   |
     |   Database needs to be created and populated with      |
     |   the initial content in DatabaseInitialContent.json   |
     ----------------------------------------------------------
     */
    var newsStructList = [NewsStruct]()
    
    // The function is given in UtilityFunctions.swift
    newsStructList = decodeJsonFileIntoArrayOfStructs(fullFilename: "DatabaseInitialContent.json", fileLocation: "Main Bundle")
    
    for aNewsItem in newsStructList {
        
        // Instantiate a new Country object and dress it up
        let newNewsItem = News(
            sourceName: aNewsItem.sourceName,
            author: aNewsItem.author,
            title: aNewsItem.title,
            description: aNewsItem.description,
            url: aNewsItem.url,
            urlToImage: aNewsItem.urlToImage,
            publishedAt: aNewsItem.publishedAt,
            content: aNewsItem.content
        )
        
        // Insert the new Country object into the database
        modelContext.insert(newNewsItem)
    }   // End of the for loop
    
    /*
     =================================
     |   Save All Database Changes   |
     =================================
     
     🔴 NOTE: Database changes are automatically saved and SwiftUI Views are
     automatically refreshed upon State change in the UI or after a certain time period.
     But sometimes, you can manually save the database changes just to be sure.
     */
    do {
        try modelContext.save()
    } catch {
        fatalError("Unable to save database changes")
    }
    
    print("Database is successfully created!")
}
