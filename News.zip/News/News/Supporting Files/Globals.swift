//
//  Globals.swift
//  News
//
//  Created by Solaiman Ibrahimi on 2/27/24.
//

import Foundation

//-----------------------------------------
// Global Alert Title and Message Variables
//-----------------------------------------
var alertTitle = ""
var alertMessage = ""

//-------------------------------
// My Currency Conversion API Key
//-------------------------------
let myNewsApiKey = "56d3e9ca51264720a8e146806287b76c"

//--------------------------------
// REST Countries API HTTP Headers
//--------------------------------

let newsApiHeaders = [
     "x-api-key": myNewsApiKey,        // ****news API key to be set in Globals.swift
     "accept": "application/json",
     "cache-control": "no-cache",
     "connection": "keep-alive",
     "host": "newsapi.org"
 ]
 

