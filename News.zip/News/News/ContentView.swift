//
//  ContentView.swift
//  News
//
//  Created by Solaiman Ibrahimi on 2/22/24.
//

import SwiftUI
import SwiftData

struct ContentView: View {
    var body: some View {
        TabView {
            Home()
                .tabItem {
                    Label("Home", systemImage: "house.fill")
                }
            FavoritesList()
                .tabItem {
                    Label("Favorites", systemImage: "star.fill")
                }
            SearchTopNewsHeadlines()
                .tabItem {
                    Label("Headlines", systemImage: "magnifyingglass")
                }
            SearchNews()
                .tabItem {
                    Label("News", systemImage: "magnifyingglass.circle.fill")
                }
            More()
                .tabItem {
                    Label("More", systemImage: "line.3.horizontal")
                }
        }
    }

}

#Preview {
    ContentView()
}
