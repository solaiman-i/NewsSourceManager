//
//  Home.swift
//  News
//
//  Created by Solaiman Ibrahimi on 2/22/24.
//

import SwiftUI

fileprivate let imageNames = ["photo1", "photo2", "photo3", "photo4", "photo5", "photo6", "photo7", "photo8", "photo9"]
fileprivate let numberOfImages = 9
fileprivate let imageCaptions = ["National Broadcasting Company (NBC) News", "Columbia Broadcasting System (CBS) News", "Cable News Network (CNN)", "USA Today", "Reuters (news and media division of Thomson Reuters)", "Microsoft/National Broadcasting Company (MSNBC)", "American Broadcasting Company (ABC) News", "National Public Radio (NPR)", "The Washington Post"]

struct Home: View {
    
    @AppStorage("darkMode") private var darkMode = false
    
    @State private var index = 0

    @State private var timer = Timer.publish(every: 3, on: .main, in: .common).autoconnect()
    
    var body: some View {
        ZStack {
            Color.gray.opacity(0.1).edgesIgnoringSafeArea(.all)
            
        ScrollView(.vertical, showsIndicators: false) {
            VStack {
                Image("Welcome")
                    .padding(.top, 30)
                    .padding(.bottom, 20)
                
                Image(imageNames[index])
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(minWidth: 300, maxWidth: 500, alignment: .center)
                    .padding(10)
                
                    .onReceive(timer) { _ in
                        index += 1
                        if index > numberOfImages - 1 {
                            index = 0
                        }
                    }
                
                Text(imageCaptions[index])
                    .font(.system(size: 14, weight: .light, design: .serif))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                
                Text("Powered By")
                    .font(.system(size: 18, weight: .light, design: .serif))
                    .italic()
                    .padding(.top, 30)
                    .padding(.bottom, 10)
                    
                Link(destination: URL(string: "https://newsapi.org")!) {
                    HStack {
                        Image("NewsApiLogo")
                            .resizable()
                            .frame(height: 20)
                            .frame(width: 60)
                        Text("News API")
                            .frame(alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            
                            
                    }
                }
                .padding(.bottom, 100)
                
            }   // End of VStack
        }   // End of ScrollView
        .onAppear() {
            startTimer()
        }
        .onDisappear() {
            stopTimer()
        }

        }   // End of ZStack
    }   // End of var
    
    func startTimer() {
        timer = Timer.publish(every: 3, on: .main, in: .common).autoconnect()
    }
    
    func stopTimer() {
        timer.upstream.connect().cancel()
    }
    
}


#Preview {
    Home()
}
