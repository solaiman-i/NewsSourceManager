//
//  SearchNews.swift
//  News
//
//  Created by Solaiman Ibrahimi on 2/22/24.
//

//
//  SearchTopNewsHeadlines.swift
//  News
//
//  Created by Solaiman Ibrahimi on 2/22/24.
//

import SwiftUI

struct SearchNews: View {
    
    var newsApiEndpoints = ["Top Headlines", "Everything"]
    @State private var selectedApiEndpointIndex = 0
    
    let newsSortOptions = ["Publication Date", "Popularity"]
    @State private var selectedNewsSortOptionIndex = 0
    
    @State private var searchFieldValue = ""
    @State private var searchCompleted = false
    @State private var showAlertMessage = false
    
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack {
                        Spacer()
                        Image("NewsApiLogo")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(height: 50)
                        Spacer()
                    }
                }
                Section(header: Text("Select News API Endpoint")) {
                    Picker("Select New Api Endpoint", selection: $selectedApiEndpointIndex) {
                        ForEach(0 ..< newsApiEndpoints.count, id: \.self) { index in
                           Text(newsApiEndpoints[selectedApiEndpointIndex]).tag(selectedApiEndpointIndex)
                       }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .padding(.horizontal)
                }
                Section(header: Text("Select news sort option")){
                    Picker("Select News Sort Option", selection: $selectedNewsSortOptionIndex) {
                        ForEach(0 ..< newsSortOptions.count, id: \.self) { index in
                           Text(newsSortOptions[selectedNewsSortOptionIndex]).tag(selectedNewsSortOptionIndex)
                       }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .padding(.horizontal)
                }
                
                Section(header: Text("Enter search string")) {
                    HStack {
                        TextField("Enter Search Query", text: $searchFieldValue)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .disableAutocorrection(true)
                        
                        // Button to clear the text field
                        Button(action: {
                            searchFieldValue = ""
                            showAlertMessage = false
                            searchCompleted = false
                        }) {
                            Image(systemName: "clear")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                        
                    }   // End of HStack
                }
                
                Section(header: Text("Search news")) {
                    HStack {
                        Spacer()
                        Button(searchCompleted ? "Search Completed" : "Search") {
                            searchTopNewsHeadlines()
                            searchCompleted = true
                        }
                        .tint(.blue)
                        .buttonStyle(.bordered)
                        .buttonBorderShape(.capsule)
                        Spacer()
                    }   // End of HStack
                }
                
                if searchCompleted {
                    Section(header: Text("List News Items Found")) {
                        NavigationLink(destination: showSearchResults) {
                            HStack {
                                Image(systemName: "list.bullet")
                                    .imageScale(.medium)
                                    .font(Font.title.weight(.regular))
                                Text("List News Items Found")
                                    .font(.system(size: 16))
                            }
                            .foregroundColor(.blue)
                        }
                    }
                }
                
            }   // End of Form
            .navigationTitle("Search worldwide news in english")
            .toolbarTitleDisplayMode(.inline)
            .alert(alertTitle, isPresented: $showAlertMessage, actions: {
                Button("OK") {}
            }, message: {
                Text(alertMessage)
            })
            
        }   // End of NavigationStack
        
    }   // End of body var
    
    /*
     ----------------
     MARK: Search API
     ----------------
     */
    func searchTopNewsHeadlines() {
        getNewsFromApi(category: newsApiEndpoints[selectedApiEndpointIndex], query: newsSortOptions[selectedNewsSortOptionIndex])
    }
    
    /*
     -------------------------
     MARK: Show Search Results
     -------------------------
     */
    var showSearchResults: some View {
        
        // Global array foundCountriesList is given in CountryApiData.swift
        if foundNewsList.isEmpty {
            return AnyView(
                NotFound(message: "No News Article Found")
            )
        }
        
        return AnyView(NewsSearchResultList())
    }
    
}


#Preview {
    SearchTopNewsHeadlines()
}



#Preview {
    SearchNews()
}
