//
//  More.swift
//  News
//
//  Created by Solaiman Ibrahimi on 2/22/24.
//

import SwiftUI

struct More: View {
    var body: some View {
        NavigationStack {
            List {
                NavigationLink(destination: NewsPublishersList()) {
                    HStack {
                        Image(systemName: "building.2.fill")
                            .imageScale(.medium)
                            .font(Font.title.weight(.regular))
                            .foregroundColor(.blue)
                            .frame(width: 40)
                        Text("News Publishers")
                            .font(.system(size: 16))
                    }
                }
                NavigationLink(destination: FavoriteNewsGrid()) {
                    HStack {
                        Image(systemName: "square.grid.3x3.fill")
                            .imageScale(.medium)
                            .font(Font.title.weight(.regular))
                            .foregroundColor(.blue)
                            .frame(width: 40)
                        Text("Favorie News Grid")
                            .font(.system(size: 16))
                    }
                }
                NavigationLink(destination: Settings()) {
                    HStack {
                        Image(systemName: "gear")
                            .imageScale(.medium)
                            .font(Font.title.weight(.regular))
                            .foregroundColor(.blue)
                            .frame(width: 40)
                        Text("Settings")
                            .font(.system(size: 16))
                    }
                }
            }   // End of List
            .navigationTitle("More")
            .toolbarTitleDisplayMode(.inline)
            
        }   // End of NavigationStack
    }   // End of body var
}

#Preview {
    More()
}
