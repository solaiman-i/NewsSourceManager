//
//  FavoriteNewsGrid.swift
//  News
//
//  Created by Solaiman Ibrahimi on 2/22/24.
//

import SwiftUI
import SwiftData

struct FavoriteNewsGrid: View {

    @Query(FetchDescriptor<News>(sortBy: [SortDescriptor(\News.sourceName, order: .forward)])) private var listOfAllNewsSourcesInDatabase: [News]
    
    @State private var showAlertMessage = false
    
    // Fit as many images per row as possible with minimum image width of 100 points each.
    // spacing defines spacing between columns
    let columns = [ GridItem(.adaptive(minimum: 100), spacing: 3) ]
    
    var body: some View {
        
            NavigationStack {
                VStack {
                    Text("These articles are found in your Favorites list")
                        .font(.system(size: 18, weight: .light, design: .serif))
                        .italic()
                        .multilineTextAlignment(.center)
                    ScrollView {
                        // spacing defines spacing between rows
                        LazyVGrid(columns: columns, spacing: 3) {
                            // 🔴 Specifying id: \.self is critically important to prevent photos being listed as out of order
                            ForEach(listOfAllNewsSourcesInDatabase) { aNewsStruct in
                                getImageFromUrl(url: aNewsStruct.urlToImage, defaultFilename: "ImageUnavailable")
                                    .resizable()
                                    .scaledToFit()
                                    .onTapGesture {
                                        alertTitle = aNewsStruct.sourceName
                                        alertMessage = aNewsStruct.title
                                        showAlertMessage = true
                                    }
                            }
                        }   // End of LazyVGrid
                        .padding()
                        
                    }   // End of ScrollView
                    
                }   // End of VStack
                .navigationTitle("Tap News Image To Get Its Info")
                .toolbarTitleDisplayMode(.inline)
                .alert(alertTitle, isPresented: $showAlertMessage, actions: {
                    Button("OK") {}
                }, message: {
                    Text(alertMessage)
                })
            }
    }
}

#Preview {
    FavoriteNewsGrid()
}
