//
//  NewsSearchResultItem.swift
//  News
//
//  Created by Solaiman Ibrahimi on 2/22/24.
//

import SwiftUI

struct NewsSearchResultItem: View {
    
    // Input Parameter
    let newsStruct: NewsStruct
    
    var body: some View {
        HStack {
            getImageFromUrl(url: newsStruct.url, defaultFilename: "ImageUnavailable")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 100)
            
            VStack(alignment: .leading) {
                Text(newsStruct.sourceName)
                Text(newsStruct.content)
                Text(newsStruct.publishedAt)
            }
            .font(.system(size: 14))
        }
    }
}

