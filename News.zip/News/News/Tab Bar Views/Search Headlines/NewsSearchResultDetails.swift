//
//  NewsSearchResultDetails.swift
//  News
//
//  Created by Solaiman Ibrahimi on 2/22/24.
//

import SwiftUI
import SwiftData

struct NewsSearchResultDetails: View {
    
    // Input Parameter
    let newsStruct: NewsStruct
    
    @Environment(\.modelContext) private var modelContext
    
    //-----------------------------------------------------
    // Create a list of all Country objects in the database
    //-----------------------------------------------------
    @Query private var newsList: [News]
    @State private var showAlertMessage = false
    
    var body: some View {
        
        return AnyView(
            // A Form cannot have more than 10 Sections.
            // Group the Sections if more than 10.
            Form {
                Group {
                    Section(header: Text("Country Common Name"), footer: Text("Common Name of the Country").italic()) {
                        Text(newsStruct.sourceName)
                    }
                    Section(header: Text("Country Official Name"), footer: Text("Official Name of the Country").italic()) {
                        Text(newsStruct.title)
                    }
                    Section(header: Text("Country Flag Image"), footer: Text("Official Flag of the Country").italic()) {
                        
                        getImageFromUrl(url: newsStruct.urlToImage, defaultFilename: "ImageUnavailable")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(minWidth: 300, maxWidth: 320, alignment: .center)
                            .contextMenu {
                                Button(action: {        // Context Menu Item
                                    // Copy the flag image to universal clipboard for pasting elsewhere
                                    UIPasteboard.general.image = getUIImageFromUrl(url: newsStruct.urlToImage, defaultFilename: "ImageUnavailable")
                                    
                                    showAlertMessage = true
                                    alertTitle = "Flag Image is Copied to Clipboard"
                                    alertMessage = "You can paste it on your iPhone, iPad, Mac laptop or Mac desktop each running under your Apple ID"
                                }) {
                                    Image(systemName: "doc.on.doc")
                                    Text("Copy")
                                }
                            }
                    }
                    Section(header: Text("Country Code Alpha 2"), footer: Text("ISO Standard Two-Letter Country Code").italic()) {
                        Text(newsStruct.content)
                    }
                    
                    Section(header: Text("Country Code Alpha 3"), footer: Text("ISO Standard Three-Letter Country Code").italic()) {
                        Text(newsStruct.publishedAt)
                    }
                }
                Group {
                    Section(header: Text("Add this country to my favorites list")) {
                        Button(action: {
                            var alreadyInDatabase = false
                            for aNews in newsList {
                                if aNews.sourceName == newsStruct.sourceName {
                                    alreadyInDatabase = true
                                    break
                                }
                            }
                            
                            if alreadyInDatabase {
                                alertTitle = "News Source in Database"
                                alertMessage = "This News Source already exists in your favorites list."
                                showAlertMessage = true
                            } else {
                                // Instantiate a new Country object and dress it up
                                let newNews = News(
                                    sourceName: newsStruct.sourceName,
                                    author: newsStruct.author,
                                    title: newsStruct.title,
                                    description: newsStruct.description,
                                    url: newsStruct.url,
                                    urlToImage: newsStruct.urlToImage,
                                    publishedAt: newsStruct.publishedAt,
                                    content: newsStruct.content
                                )
                                
                                // Insert the new Country object into the database
                                modelContext.insert(newNews)
                                
                                alertTitle = "News Source Added"
                                alertMessage = "This News Source is added to your favorites list."
                                showAlertMessage = true
                            }
                        }) {
                            HStack {
                                Image(systemName: "plus")
                                    .imageScale(.medium)
                                    .font(Font.title.weight(.regular))
                                    .foregroundColor(.blue)
                                Text("Add News Source to Favorites")
                                    .font(.system(size: 16))
                            }
                        }
                    }
                }
            }   // End of Form
                .font(.system(size: 14))
                .navigationTitle("Found News Details")
                .toolbarTitleDisplayMode(.inline)
                .alert(alertTitle, isPresented: $showAlertMessage, actions: {
                    Button("OK") {}
                }, message: {
                    Text(alertMessage)
                })
            
        )   // End of AnyView
    }   // End of body var
}

/*
 struct FoundCountryLocationOnMap: View {
 
 // Input Parameters
 let countryStruct: CountryStruct
 let mapStyleIndex: Int
 
 @State private var mapCameraPosition: MapCameraPosition = .region(
 MKCoordinateRegion(
 center: mapCenterCoordinate,
 // 1 degree = 69 miles. 30 degrees = 2,070 miles
 span: MKCoordinateSpan(
 latitudeDelta: 30,
 longitudeDelta: 30)
 )
 )
 
 var body: some View {
 
 var mapStyle: MapStyle = .standard
 
 switch mapStyleIndex {
 case 0:
 mapStyle = MapStyle.standard
 case 1:
 mapStyle = MapStyle.imagery     // Satellite
 case 2:
 mapStyle = MapStyle.hybrid
 case 3:
 mapStyle = MapStyle.hybrid(elevation: .realistic)   // Globe
 default:
 print("Map style is out of range!")
 }
 
 return AnyView(
 Map(position: $mapCameraPosition) {
 Marker(countryStruct.commonName, coordinate: mapCenterCoordinate)
 }
 .mapStyle(mapStyle)
 .navigationTitle(countryStruct.commonName)
 .toolbarTitleDisplayMode(.inline)
 )
 }
 
 }
 */
