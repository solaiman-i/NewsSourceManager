//
//  SearchTopNewsHeadlines.swift
//  News
//
//  Created by Solaiman Ibrahimi on 2/22/24.
//

import SwiftUI

struct SearchTopNewsHeadlines: View {
    
    var newsSortOptions = ["Date", "Popularity", "Relevancy"]
    @State private var selectedSortOptionIndex = 0
    
    let newsCategories = ["All", "Business", "Entertainment", "General", "Health", "Science", "Sports", "Technology"]
    @State private var selectedIndex = 0
    @State private var searchCompleted = false
    @State private var showAlertMessage = false
    
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack {
                        Spacer()
                        Image("NewsApiLogo")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(height: 50)
                        Spacer()
                    }
                }
                Section(header: Text("Select Search Category")) {
                    Picker("", selection: $selectedIndex) {
                        ForEach(0 ..< newsCategories.count, id: \.self) {
                            Text(newsCategories[$0])
                        }
                    }
                }
                Section(){
                    Picker("Select Map Style", selection: $selectedSortOptionIndex) {
                        ForEach(0 ..< newsSortOptions.count, id: \.self) { index in
                           Text(newsSortOptions[index]).tag(index)
                       }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .padding(.horizontal)
                }
                
                Section(header: Text("Search headline news in usa")) {
                    HStack {
                        Spacer()
                        Button(searchCompleted ? "Search Completed" : "Search") {
                            searchTopNewsHeadlines()
                            searchCompleted = true
                        }
                        .tint(.blue)
                        .buttonStyle(.bordered)
                        .buttonBorderShape(.capsule)
                        Spacer()
                    }   // End of HStack
                }
                
                if searchCompleted {
                    Section(header: Text("List News Items Found")) {
                        NavigationLink(destination: showSearchResults) {
                            HStack {
                                Image(systemName: "list.bullet")
                                    .imageScale(.medium)
                                    .font(Font.title.weight(.regular))
                                Text("List News Items Found")
                                    .font(.system(size: 16))
                            }
                            .foregroundColor(.blue)
                        }
                    }
                }
                
            }   // End of Form
            .navigationTitle("Search Headline News in USA")
            .toolbarTitleDisplayMode(.inline)
            .alert(alertTitle, isPresented: $showAlertMessage, actions: {
                Button("OK") {}
            }, message: {
                Text(alertMessage)
            })
            
        }   // End of NavigationStack
        
    }   // End of body var
    
    /*
     ----------------
     MARK: Search API
     ----------------
     */
    func searchTopNewsHeadlines() {
        getNewsFromApi(category: newsCategories[selectedIndex], query: newsSortOptions[selectedSortOptionIndex])
    }
    
    /*
     -------------------------
     MARK: Show Search Results
     -------------------------
     */
    var showSearchResults: some View {
        if searchCompleted {
            if foundNewsList.isEmpty {
                return AnyView(
                    NotFound(message: "No News Article Found")
                )
            } else {
                return AnyView(NewsSearchResultList())
            }
        } else {
            return AnyView(EmptyView())
        }
    }
    
}


#Preview {
    SearchTopNewsHeadlines()
}

