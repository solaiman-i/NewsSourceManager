//
//  NewsSearchResultList.swift
//  News
//
//  Created by Solaiman Ibrahimi on 2/22/24.
//

import SwiftUI

struct NewsSearchResultList: View {
    var body: some View {
        
        List {
            // 'id' can be specified as either 'self' or a unique attribute such as 'cca3'
            ForEach(foundNewsList, id: \.publishedAt) { aNewsStruct in
                NavigationLink(destination: NewsSearchResultDetails(newsStruct: aNewsStruct)) {
                    NewsSearchResultItem(newsStruct: aNewsStruct)
                }
            }
        }
        .navigationTitle("API Search Results")
        .toolbarTitleDisplayMode(.inline)
         
    }
}

#Preview {
    NewsSearchResultList()
}

