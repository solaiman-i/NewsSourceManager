//
//  FavoritesList.swift
//  News
//
//  Created by Solaiman Ibrahimi on 2/22/24.
//

import SwiftUI
import SwiftData

struct FavoritesList: View {
    
    @Environment(\.modelContext) private var modelContext

    // Obtain all countries in the database as sorted alphabetically w.r.t. news commonName
    @Query(FetchDescriptor<News>(sortBy: [SortDescriptor(\News.sourceName, order: .forward)])) private var listOfAllNewsSourcesInDatabase: [News]
    
    @State private var toBeDeleted: IndexSet?
    @State private var showConfirmation = false
    
    var body: some View {
        NavigationStack {
            List {
                /*
                 ForEach requires a unique id for each list item to be able to dynamically list them as scrollable.
                */
                ForEach(listOfAllNewsSourcesInDatabase) { aNewsSource in
                    NavigationLink(destination: FavoriteDetails(news: aNewsSource)) {
                        FavoriteItem(news: aNewsSource)
                            .alert(isPresented: $showConfirmation) {
                                Alert(title: Text("Delete Confirmation"),
                                      message: Text("Are you sure to permanently delete the news item?"),
                                      primaryButton: .destructive(Text("Delete")) {
                                    /*
                                    'toBeDeleted (IndexSet).first' is an unsafe pointer to the index number of the array
                                     element to be deleted. It is nil if the array is empty. Process it as an optional.
                                    */
                                    if let index = toBeDeleted?.first {
                                        let newsSourceToDelete = listOfAllNewsSourcesInDatabase[index]
                                        modelContext.delete(newsSourceToDelete)
                                    }
                                    toBeDeleted = nil
                                }, secondaryButton: .cancel() {
                                    toBeDeleted = nil
                                }
                            )
                        }   // End of alert
                    }   // End of NavigationLink
                }   // End of ForEach
                .onDelete(perform: delete)
                
            }   // End of List
            .navigationTitle("Favorites")
            .toolbarTitleDisplayMode(.inline)
            .toolbar {
                // Place the Edit button on left side of the toolbar
                ToolbarItem(placement: .topBarLeading) {
                    EditButton()
                }
            }
            
        }   // End of NavigationStack
    }
    
    /*
     -----------------------------
     MARK: Delete Selected news item
     -----------------------------
     */
    private func delete(offsets: IndexSet) {
        toBeDeleted = offsets
        showConfirmation = true
    }
}

#Preview {
    FavoritesList()
}

