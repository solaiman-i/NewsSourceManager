//
//  FavoriteDetails.swift
//  News
//
//  Created by Solaiman Ibrahimi on 2/22/24.
//

import SwiftUI
import MapKit

fileprivate var mapCenterCoordinate = CLLocationCoordinate2D(latitude: 0.0, longitude: 0.0)

struct FavoriteDetails: View {
    
    // Input Parameter
    let news: News
    
    @State private var showAlertMessage = false
    
    var body: some View {
        
        return AnyView(
            // A Form cannot have more than 10 Sections.
            // Group the Sections if more than 10.
            Form {
                Group {
                    Section(header: Text("News Item Source Name")) {
                        Text(news.sourceName)
                    }
                    Section(header: Text("News Item Image")) {
                        
                        getImageFromUrl(url: news.urlToImage, defaultFilename: "ImageUnavailable")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            // Flag image is obtained from the API with width of 320
                            .frame(minWidth: 300, maxWidth: 320, alignment: .center)
                            .contextMenu {
                                Button(action: {        // Context Menu Item
                                    // Copy the flag image to universal clipboard for pasting elsewhere
                                    UIPasteboard.general.image = getUIImageFromUrl(url: news.urlToImage, defaultFilename: "ImageUnavailable")
                                    
                                    showAlertMessage = true
                                    alertTitle = "News Source is Copied to Clipboard"
                                    alertMessage = "You can paste it on your iPhone, iPad, Mac laptop or Mac desktop each running under your Apple ID"
                                }) {
                                    Image(systemName: "doc.on.doc")
                                    Text("Copy")
                                }
                            }
                    }
                    Section(header: Text("News Item Title")) {
                        Text(news.title)
                    }
                    Section(header: Text("News Item Publisher Website")) {
                        HStack{
                            Image(systemName: "earth")
                            Text(news.url)
                        }
                        
                    }
                }
                Group {
                    Section(header: Text("News Item Author")) {
                        Text(news.author)
                    }
                    Section(header: Text("News Item Description")) {
                        Text(news.desc)
                    }
                    Section(header: Text("News Item Publication Date And Time")) {
                        Text(news.publishedAt)
                    }
                    Section(header: Text("News Item Content")) {
                        Text(news.content)
                    }
                }
                
            }   // End of Form
            .navigationTitle("News Item Details")
            .toolbarTitleDisplayMode(.inline)
            .font(.system(size: 14))
            .alert(alertTitle, isPresented: $showAlertMessage, actions: {
                Button("OK") {}
            }, message: {
                Text(alertMessage)
            })
            
        )   // End of AnyView
    }   // End of body var
}
