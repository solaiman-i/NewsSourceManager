//
//  FavoriteItem.swift
//  News
//
//  Created by Solaiman Ibrahimi on 2/22/24.
//

import SwiftUI

struct FavoriteItem: View {
    
    // Input Parameter
    let news: News
    
    var body: some View {
        HStack {
            getImageFromUrl(url: news.urlToImage, defaultFilename: "ImageUnavailable")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 100)
            
            VStack(alignment: .leading) {
                Text(news.sourceName)
                Text(news.title)
                Text(news.publishedAt)
            }
            .font(.system(size: 14))
        }
    }
}
